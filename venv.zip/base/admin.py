from django.contrib import admin
from .models import studySummary, Topic, chek
# Register your models here.
admin.site.register(studySummary)
admin.site.register(Topic)
admin.site.register(chek)
